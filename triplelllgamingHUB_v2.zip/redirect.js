if (window.location.pathname === "/") {
  window.location.href = "/home";
        }